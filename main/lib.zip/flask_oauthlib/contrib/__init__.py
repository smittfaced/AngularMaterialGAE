# coding: utf-8
"""
    flask_oauthlib.contrib
    ~~~~~~~~~~~~~~~~~~~~~~

    Contributions for Flask OAuthlib.

    :copyright: (c) 2013 - 2014 by Hsiaoming Yang.
"""
